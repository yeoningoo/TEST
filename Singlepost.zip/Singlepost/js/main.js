// JavaScript Document
$(function(){
	
	//Slide 부분 변수 설정
	banner = $('.banner');
	items = banner.find('li');
	itemsLength = items.length;
	current = 1;
	first = items.filter(':first');
	last = items.filter(':last');
	first.before(last.clone(true));
	last.after(first.clone(true));
	
	//첫 화면에서는 첫번째 슬라이드 버튼에 불이 들어와 있어야 한다
	$('.number li:first').addClass('active');
	
	//Slide 부분, 버튼 클릭하면 해당 슬라이드로 넘어가기!
	$('.number li').click(function(){
		var su = $(this).index()+1;
		if(banner.is(':not(:animated)')){
			banner.animate({left:-(721*su)});
			current = su;
			numberfn(current);
		}
	});
	
	//Slide 부분, 3초마다 자동으로 전환시키기!
	//하지만 마우스 오버 했을 때는 잠깐 멈추게 하기!
	var run = setInterval('rotate()',3000);
	$('.mainSlide').hover(function(){
		clearInterval(run);	
	},
	function(){
		run = setInterval('rotate()',3000);	
	});
});


//함수 설정들

//슬라이드에 해당하는 숫자 색깔 바꾸기
function numberfn(num){
	$('.number li').each(function(){
		if((num-1) == $(this).index()){
			$('.number li').removeClass('active');
			$(this).addClass('active');	
		}
	});
}

//슬라이드 자동 회전
function rotate(){
		if(banner.is(':not(:animated)')){
			banner.animate({left:'-='+(721)}, function(){
				current++;
				if(current > itemsLength){
					current=1;
					banner.css({left:-721});
				}
			numberfn(current);
			});
		}
}


